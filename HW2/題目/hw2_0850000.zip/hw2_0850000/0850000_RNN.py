"""
Code for the in-class competetion of RNN
"""
